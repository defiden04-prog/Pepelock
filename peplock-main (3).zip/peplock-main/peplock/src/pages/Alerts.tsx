export default function Alerts() {
    return (
        <div className="grid gap-4 min-h-screen justify-center items-center">
            {/* Add your settings content here */}
            <div className="p-6 rounded-lg bg-black/20 backdrop-blur-lg border border-white/5">
                <p className="text-white/60 font-mono">Alerts coming soon</p>
            </div>
        </div>
    )
} 